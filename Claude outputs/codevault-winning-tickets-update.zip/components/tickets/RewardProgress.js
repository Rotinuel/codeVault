import { Gift, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

/** Shows the Super Admin's discount tiers and where the client stands. */
export function RewardProgress({ reward, compact = false }) {
  if (!reward?.enabled || !reward.tiers?.length) return null;
  const max = reward.tiers[reward.tiers.length - 1].minTickets;
  const pct = Math.min(100, Math.round((reward.available / max) * 100));

  return (
    <div className={cn("card overflow-hidden", compact && "shadow-none")}>
      <div className="relative bg-linear-to-br from-ink-900 to-ink-800 p-5 text-white">
        <div className="grid-bg absolute inset-0 opacity-50" aria-hidden="true" />
        <div className="relative flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gold-400">
              <Trophy className="size-4" aria-hidden="true" /> Winners&apos; reward
            </p>
            <p className="mt-2 text-2xl font-semibold">
              {reward.percent ? `${reward.percent}% off your next payment` : "Upload winning tickets, pay less"}
            </p>
            <p className="mt-1 text-sm text-slate-300">
              {reward.percent
                ? "Applied automatically at checkout. The tickets it uses are then marked as redeemed."
                : reward.next
                  ? `${reward.next.ticketsNeeded} more approved ticket${reward.next.ticketsNeeded === 1 ? "" : "s"} unlocks ${reward.next.percent}% off.`
                  : "Every approved ticket counts towards a discount."}
              {reward.percent && reward.next ? ` Collect ${reward.next.ticketsNeeded} more for ${reward.next.percent}% instead.` : ""}
            </p>
          </div>
          <div className="rounded-xl bg-white/10 px-4 py-3 text-center ring-1 ring-white/10">
            <p className="text-3xl font-bold tabular-nums">{reward.available}</p>
            <p className="text-xs text-slate-300">approved, unused</p>
          </div>
        </div>
        <div className="relative mt-5">
          <div className="h-2 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuenow={reward.available} aria-valuemin={0} aria-valuemax={max} aria-label="Approved tickets towards the top reward">
            <div className="h-full rounded-full bg-linear-to-r from-gold-400 to-gold-500" style={{ width: `${Math.max(pct, reward.available ? 4 : 0)}%` }} />
          </div>
        </div>
      </div>
      <ul className="grid gap-2 p-4 sm:grid-cols-3">
        {reward.tiers.map((t) => {
          const reached = reward.available >= t.minTickets;
          const current = reward.percent === t.percent;
          return (
            <li
              key={t.minTickets}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3.5 py-3 ring-1",
                current ? "bg-brand-50 ring-brand-300" : reached ? "bg-slate-50 ring-slate-200" : "bg-white ring-slate-200"
              )}
            >
              <Gift className={cn("size-5 shrink-0", reached ? "text-brand-600" : "text-slate-300")} aria-hidden="true" />
              <div>
                <p className="text-sm font-semibold text-slate-900">{t.percent}% off</p>
                <p className="text-xs text-slate-500">
                  {t.minTickets} approved ticket{t.minTickets === 1 ? "" : "s"}
                  {current ? " · your reward" : ""}
                </p>
              </div>
            </li>
          );
        })}
      </ul>
      {reward.validityDays > 0 && (
        <p className="px-4 pb-4 text-xs text-slate-500">Approved tickets count for {reward.validityDays} days after approval.</p>
      )}
    </div>
  );
}
